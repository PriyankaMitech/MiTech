# Datepicker in Bootstrap 5

A Pen created on CodePen.io. Original URL: [https://codepen.io/vsfvjiuv-the-typescripter/pen/mdMeJwL](https://codepen.io/vsfvjiuv-the-typescripter/pen/mdMeJwL).

