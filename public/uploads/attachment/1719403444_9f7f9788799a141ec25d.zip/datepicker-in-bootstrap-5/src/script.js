$(function(){
  $('#datepicker').datepicker();
});